Version: (v2.0-2018)
1. Beschreibung:
Darstellung einer interaktiven Karte, die abhängig vom Zoomlevel die angezeigten Karten-Marker clustered.
Der Klick auf einen Kartenmarker öffnet ein Popup mit weiteren Informationen zum Standort und der Möglichkeit, das dahinterliegende Medienelement vom Mediathek-Server abspielen zu lassen.
Die Daten für die angezeigten Kartenmarker werden von Schnittstellen der Österreichischen Mediathek geladen und abhängig vom eingestellten Suchfilter gefiltert.
Der Suchfilter umfasst Themen, Zeitraum, Bezirk und Freitext, des weiteren kann über den Standortbutton die aktuelle Position des Nutzers auf der Karte dargestellt werden.
Zusätzlich können über den Menüpunkt "Stadtspaziergänge" Routen angezeigt werden; diese werden über das Format gpx von einer Schnittstelle der Österreischen Mediathek geladen.
Es besteht des weiteren auch die Möglichkeit verschiedener Datenquellen darzustellen und zu diese seperat zu filtern.

2. Verwendetete Bibliotheken:

jQuery
https://jquery.com/
Lizenz:
https://jquery.org/license/
Licensed under the The MIT License (MIT)

Twitter Bootstrap:
http://getbootstrap.com
Lizenz:
Code and documentation copyright 2011-2015 Twitter, Inc. Code released under [the MIT license](https://github.com/twbs/bootstrap/blob/master/LICENSE). Docs released under [Creative Commons](https://github.com/twbs/bootstrap/blob/master/docs/LICENSE).

Knockout 
http://knockoutjs.com/
Lizenz:
https://github.com/knockout/knockout/blob/master/LICENSE
Licensed under the The MIT License (MIT)

History.JS
https://github.com/browserstate/history.js
Lizenz:
https://github.com/browserstate/history.js/blob/master/LICENSE.md
Licensed under the New BSD License 
Copyright © 2014+ Bevry Pty Ltd us@bevry.me 
Copyright © 2011-2013 Benjamin Arthur Lupton b@lupton.cc

jScrollPane
http://jscrollpane.kelvinluck.com/ 
Lizenz:
https://github.com/vitch/jScrollPane/blob/master/MIT-LICENSE.txt
Licensed under the The MIT License (MIT)

Leaflet
http://leafletjs.com/
Lizenz:
https://github.com/Leaflet/Leaflet/blob/master/LICENSE

Leaflet-gpx
https://github.com/mpetazzoni/leaflet-gpx
Lizenz:
https://github.com/mpetazzoni/leaflet-gpx/blob/master/LICENSE


Leaflet.markercluster
https://github.com/Leaflet/Leaflet.markercluster
Lizenz:
https://github.com/Leaflet/Leaflet.markercluster/blob/master/MIT-LICENCE.txt
Licensed under the The MIT License (MIT)

Leafpile:
https://github.com/cavis/leafpile
Lizenz:
https://github.com/cavis/leafpile/blob/master/MIT-LICENSE
Licensed under the The MIT License (MIT)

Bootstrap Slider
https://github.com/seiyria/bootstrap-slider
Lizenz:
https://github.com/seiyria/bootstrap-slider/blob/master/LICENSE.md
Licensed under the The MIT License (MIT)

Verwendtes Kartenmaterial stammt von:
http://www.mapquest.com/
http://www.openstreetmap.org/copyright


3. Installationsanleitung:

3.1 Benötigte Software:

NodeJS
https://nodejs.org/en/

GIT
GIT ist ein als Open Source veröffentlichtes Versions-Verwaltungssystem.
https://git-scm.com/

WICHTIG: Bei der Installation von GIT unter Windows "Use Git from the Windows Command Promt" auswählen.

GRUNT
http://gruntjs.com/
GRUNT ist ein Automatiserungs-Tool. Die Installation erfolgt über npm

$ npm install -g grunt-cli


Bower
http://bower.io/
Bower ist ein Kommandozeilen Tool. Die Installation erfolgt über npm

$ npm install -g bower
Bower benötigt node, npm and git.



Sind die benötigten Software Komponenten installiert, kann das das Projekt mit dem Tool im Root Order des Projekts gebuilded werden.

$ npm install
$ bower install
$ grunt


Ist das Projekt fertig gebuilded, befinden sich im Order dist alle benötigten Dateien, um die Applikation zu starten.

3.2 Struktur des Projekts:

dist:			
│   index.html
│
├───css
│   │   jquery.jscrollpane.custom.css	    Style für die Scrollbalken
│   │   loader.css			    Style des Loaders
│   │   main.css			    Haupt CSS Datei
│   │   mh5player.custom.css		    Custom Style für den Mediathek HTML5 Player
│   │
│   └───mediathek
│           footer.css
│           global_overide.css
│           internal.css
│
├───fonts				    Enthält alle Schriften
│       glyphicons-halflings-regular.eot
│       glyphicons-halflings-regular.svg
│       glyphicons-halflings-regular.ttf
│       glyphicons-halflings-regular.woff
│       glyphicons-halflings-regular.woff2
│
├───img				    	Bilder
│       marker-audio.png
│       marker-blue.png
│       marker-video.png
│       netidee.png
│       pin-icon-end.png
│       pin-icon-start.png
│       pin-shadow.png
│       play.png
│       slider-handle.png
│
└───js				   
    │   mapmanager.js			    Hauptjavascript
    │
    └───templates			    Seitentemplates, die über KnockoutJS gerendert werden
            all.html


Der Ordner dist gliedert sich nach dem builden folgendermaßen:

dist:
├───css		
     |  bundle.css	CSS Dateien des Projektes
     |  lib.bundle.css	gebündelte CSS der verwendeten Libraries
├───fonts		Fonts
├───img		Bilder
├───js
     |  mapmanager.js	JS Datei des Projekts
     |  lib.bundle.js	gebündelte Javascript der verwendeten Libraries
     └───templates	Templates des Projekts, diese werden über KnockoutJS geladen




index.html

Über  mGeoApp.baseurl kann das Arbeitsverzeichnis festgelegt werden.
Bsp:
	    mGeoApp.baseurl = "dist";
	