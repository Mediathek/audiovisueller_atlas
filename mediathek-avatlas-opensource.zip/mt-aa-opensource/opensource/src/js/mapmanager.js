"use strict";
var ajaxUrl = 'http://atlas.mediathek.at';
 if (location.protocol == 'https:') {
     ajaxUrl = 'https://atlas.mediathek.at';
}

var _gaq = _gaq || [];
var mGeoApp = mGeoApp || {};
var mh5App = mh5App || {};
var L = L || {};
var MQ = MQ || {};
var History = History || {};
var soundManager = soundManager || {};


(function ($) {

    mGeoApp = {
        initConfig: {},
        maps: ko.observableArray(),
        config: function () {
            return config;
        },
        root: jQuery("body"),
        components: {},
        urlParams: {},
        //Player schließen mit bestimmter ID
        closePlayer: function (atomid, instance) {
            try {

                if (mGeoApp.components.player && mGeoApp.components.player.wrapper) {
                    mGeoApp.components.player.wrapper.hide();
                }
            } catch (e) {
                console.log(e);
            }
            try {
                if (soundManager && typeof soundManager !== 'undefined') {

                    //soundManager.pauseAll();
                    if(typeof mh5App !== 'undefined' && typeof mh5App.getPlayer === 'function') {
                        var p = mh5App.getPlayer(instance.playerid);
                        p.wfp.stop();
                    }

                }
            } catch (e) {
                console.log(e);
            }
            try {
                if (mh5App && mh5App !== "undefined" && mh5App.wfp && mh5App.wfp !== "undefined") {
                    console.log('herewf');
                    mh5App.wfp.pause();
                }
            } catch (e) {
                console.log(e);
            }

        },
        //Initialsieren der Karte
        initMap: function (initConfig) {
            this.ajaxBridge.ajaxUrl = initConfig.url;
            this.initConfig = initConfig;
            ko.subscribable.fn.subscribeChanged = function (callback) {
                var oldValue;
                this.subscribe(function (_oldValue) {
                    oldValue = _oldValue;
                }, this, 'beforeChange');

                this.subscribe(function (newValue) {
                    callback(newValue, oldValue);
                });
            };


            this.tools.isMobile();
            var confurl = initConfig.url;


            mGeoApp.urlParams = urlParser.readUrl();
            var p = {};
            if(Object.keys(mGeoApp.urlParams).length > 0) {
                if(mGeoApp.urlParams.searchword) {
                    p.searchword = mGeoApp.urlParams.searchword;
                }
                p.filter = mGeoApp.urlParams;
            }


            //var search = window.location.pathname;

            var request = {
                run: 'init',
                arguments: {
                    'params': p
                }
            };

            mGeoApp.ajaxBridge.init(request, this.setConfig)

        },
        setConfig: function (conf) {
            mGeoApp.debugLocal = mGeoApp.initConfig.debugLocal;
            var map = {};
            map.playerid = "mh5mediaplayer",
                map.mapdata = {};
            map.mapdata.layerGroups = ko.observableArray([]);
            map.mapdata.markers = ko.observableArray([]);
            map.instanceID = mGeoApp.initConfig.instanceID;
            map.baseurl = conf.config.config.jsBaseUrl;
            map.urls = {
                "waypoints": {
                    "request": conf.config.waypointsCall
                },
                "search": {
                    "request": conf.config.searchCall
                },
                "walk": {
                    "request": conf.config.walkCall
                }
            };
            map.config = conf;
            map.root = jQuery("#" + mGeoApp.initConfig.instanceID);

            map.mapid = 'map';
            map.settings = {};
            map.scripts = {};
            map.data = {};
            map.data.search = {};
            map.data.search.Topics = ko.observableArray([]);
            map.data.search.PostalCodes = ko.observableArray([]);
            map.data.search.PostalCodeGroups = ko.observableArray([]);
            map.data.search.Walks = ko.observableArray([]);
            map.data.search.Clients = ko.observableArray([]);
            map.data.mylocation = ko.observable();

            map.components = {};
            map.components.search = {};
            map.components.search.isVisible = ko.observable(map.config.config.config.showSearch);
            map.components.filter = {};
            map.components.filter.isVisible = ko.observable(map.config.config.config.showFilter);
            map.components.filter.navIsHidden = ko.observable(true);
            map.components.panel = {};
            map.components.panel.isVisible = ko.observable(map.config.config.config.showPanel);

            map.components.filterresult = {};
            map.components.walks = {};
            map.components.walks.isVisible = ko.observable(map.config.config.config.showWalks);
            map.components.walks.selectedWalk = ko.observable();


            map.components.map = {};

            map.settings.ga = {};
            map.settings.ga.track = false;
            map.settings.ga.trackingid = [""];

            mGeoApp.loadModules(map);
            map.data.waypoints = ko.observableArray();


            if (!mGeoApp.components.player) {
                mGeoApp.components.player = {};
                mGeoApp.components.player.isLoaded = false;
            }


            //read initconfig
            if (map.config.config.rootElement) {
                map.root = jQuery('#' + map.config.config.rootElementID);
            }


            map.components.walks.starterWalk = mGeoApp.initConfig.starterWalk;

            if (map.config.config.starterWalk) {
                map.components.walks.starterWalk = map.config.config.starterWalk;
            }

            map.starterMarker = mGeoApp.initConfig.starterMarker;
            if (map.config.config.starterMarker) {
                map.starterMarker = map.config.config.starterMarker;
            }




            // ./ read initconfig

            mGeoApp.maps.push(map);

            return map;
        },
        getMap: function (id) {
            var map = $.grep(mGeoApp.maps(), function (e) {
                return e.instanceID === id;
            });
            return map[0];
        },
        //Marker Popup mit bestimmter ID öffnen
        openMarkerPopup: function (id, instance) {
            if (!instance) {
                instance = mGeoApp.maps()[0];
            }

            if (instance.mapdata.layerGroups() && instance.mapdata.layerGroups().length > 0) {
                jQuery.each(instance.mapdata.markers(), function (key, value) {
                    var markerID = value.options.UID;
                    if (markerID === id) {
                        instance.mapdata.layerGroups()[0].zoomToShowLayer(value, function () {
                            var delay = 1000; //1 second

                            setTimeout(function () {
                                value.openPopup();
                            }, delay);


                            // console.log(instance.components.map.getCenter());


                        });


                    }
                });
            }
        },
        //todo
        setWaypoints: function (marker, instance, starterMarker) {
            instance.data.waypoints(marker);
            this.clearLayers(instance);

            if (marker && marker.length > 0) {
                var markerAudio = L.icon({
                    iconUrl: instance.baseurl + '../img/marker-audio.png',
                    //shadowUrl: 'leaf-shadow.png',
                    iconSize: [26, 33], // size of the icon
                    shadowSize: [50, 64], // size of the shadow
                    iconAnchor: [13, 33], // point of the icon which will correspond to marker's location
                    shadowAnchor: [4, 62], // the same for the shadow
                    popupAnchor: [0, -33] // point from which the popup should open relative to the iconAnchor
                });
                var markerVideo = L.icon({
                    iconUrl: instance.baseurl + '../img/marker-video.png',
                    //shadowUrl: 'leaf-shadow.png',
                    iconSize: [26, 33], // size of the icon
                    shadowSize: [50, 64], // size of the shadow
                    iconAnchor: [13, 33], // point of the icon which will correspond to marker's location
                    shadowAnchor: [4, 62], // the same for the shadow
                    popupAnchor: [0, -33] // point from which the popup should open relative to the iconAnchor
                });


                var customMarker = L.Marker.extend({
                    options: {
                        UID: ''
                    }
                });
                var mapmarkers = [];

                var markerCluster = L.markerClusterGroup({disableClusteringAtZoom: 18 /*, maxClusterRadius:60*/});

                //console.log("width:" + $(window).width());
                //console.log("height:" + $(window).width());

                var dWidth = $(window).width();
                var dHeight = $(window).height() * 0.9;

                var minWidth = dWidth < 500 ? Math.round(dWidth * 0.9) : 350;
                var maxWidth = dWidth < 500 ? Math.round(dWidth * 0.9) : 350;

                var minHeight = dHeight < 500 ? Math.round(dHeight * 0.8) : 400;
                var maxHeight = dHeight < 500 ? Math.round(dHeight * 0.8) : 800;

                var getMarker = function (path) {
                    return L.icon({
                        iconUrl: path,
                        //shadowUrl: 'leaf-shadow.png',
                        iconSize: [26, 33], // size of the icon
                        shadowSize: [50, 64], // size of the shadow
                        iconAnchor: [13, 33], // point of the icon which will correspond to marker's location
                        shadowAnchor: [4, 62], // the same for the shadow
                        popupAnchor: [0, -33] // point from which the popup should open relative to the iconAnchor
                    });
                }

                jQuery.each(instance.data.waypoints(), function (key, value) {
                    if (value.Title) {
                        var title = (value.Title.length > 130) ? value.Title.substring(0, 130) + '…' : value.Title;
                        var desc = (value.Description.length > 200) ? value.Description.substring(0, 200) + '…' : value.Description;
                        var b = "";
                        var l = "";
                        var address = '';
                        if(value.PlaceStreet) {
                            address += value.PlaceStreet+'<br/>';
                        }

                        if(value.PlacePostalCode) {
                            address += value.PlacePostalCode+' ';
                        }

                        if(value.Place !== '') {
                            address += value.Place+'<br/>';
                        }

                        //  var popup = L.popup({ maxWidth: 350, minWidth: 280, minHeight:250, maxHeight:400, keepInView:true, autoPanPaddingTopLeft: new L.Point(0, 130)})
                        var popup = L.popup({
                            minWidth: minWidth,
                            maxWidth: maxWidth,
                            minHeight: minHeight,
                                maxHeight: maxHeight,
                                zoomAnimation: false /*, autoPanPaddingTopLeft: new L.Point(0, 0)*/
                        })
                    .setContent('<div class="popup" style="background-color: '+value.Color+'" id="popup_' + value.UniqueIdentifier + '" data-atomid="' + value.UniqueIdentifier + '"><div class="popup-logo"><img src="'+value.Logo+'"/></div>' +
                            '<div class="popup_title popup_link_click">' + title + '</div><div class="popup_description popup_link_click">' + desc + '</div>\n\
                                     <div class="popup_lower"><div class="popup_image popup_link_click">\n\
                                        <img src="' + instance.config.config.config.thumbUrl + value.UniqueIdentifier + '" width="120"/></div><div><div class="popup_address">' + address + '</div>\n\
                                        <div class="popup_link popup_link_click" ><span class="popup_linkicon" style="background-image:  url('+value.PlayIcon+')"></span><span class="popup_linktext ">Details / Medium abspielen</span></div></div></div></div>');


                        if (value && value.PlacePositionB) {
                            b = Number(value.PlacePositionB.replace(",", "."));
                        }
                        if (value && value.PlacePositionL) {
                            l = Number(value.PlacePositionL.replace(",", "."));
                        }


                        if (b && l) {
                            var myMarker = new customMarker([b, l], {
                                icon: value.Type === "audio" ? getMarker(value.MarkerAudio) : getMarker(value.MarkerVideo),
                                UID: value.UniqueIdentifier,
                                title: value.Title,
                                color: value.Color

                            });
                            myMarker.bindPopup(popup);
                            mapmarkers.push(myMarker);
                        } else {
                            console.log('Missing geolocation: '+value.IDN);
                        }
                    }

                });
                markerCluster.addLayers(mapmarkers);

                instance.mapdata.markers(mapmarkers);


                instance.components.map.fitBounds(markerCluster.getBounds());
                instance.mapdata.layerGroups.push(markerCluster);


                // if (_gaq) {
                //
                //     instance.components.map.on('popupopen', function (e) {
                //         var atomid = $(e.popup.getContent()).data("atomid");
                //
                //         jQuery.each(instance.settings.ga.trackingid, function (key, value) {
                //
                //             _gaq.push(['_setAccount', value]);
                //             _gaq.push(['_trackEvent', 'Marker', 'click', atomid]);
                //         });
                //
                //     });
                // }


                instance.components.map.addLayer(markerCluster);
                markerCluster.on("click", function (target) {
                   $('.leaflet-popup-tip').css('background-color',target.layer.options.color);
                });

                markerCluster.on("animationend", function () {
                    if (instance.starterMarker && !instance.starterMarkerSet) {
                        mGeoApp.openMarkerPopup(instance.starterMarker, instance);
                        instance.starterMarkerSet = true;
                    }
                });


                // The HTML we put in bindPopup doesn't exist yet, so we can't just say
                // $('.popup .popup_link'). Instead, we listen for click events on the map element which
                // will bubble up from the tooltip, once it's created and someone clicks on it.
                //$('#' + instance.instanceID + ' l').on('click', '.popup .popup_link, .popup img, .popup .popup_title, .popup .popup_description', function () {
                //, .popup img, .popup .popup_title, .popup .popup_description
                //$('#map_' + instance.instanceID).unbind().on('click', '.popup .popup_link', function () {
                $('#map_' + instance.instanceID).unbind().on('click', '.popup .popup_link_click', function () {
                    var atomid = 'atlas::'+$(this).closest('.popup').data("atomid");
                    mGeoApp.setPlayer(atomid, instance);
                    //jQuery('.mgeoPlayerwrapper').css('top', '50%');
                    History.pushState({
                        state: "Player",
                        instanceID: instance.instanceID,
                        atomid: 'atlas::'+atomid
                    }, $(document).find("title").text(), "?state=" + atomid);

                    // jQuery.each(instance.settings.ga.trackingid, function (key, value) {
                    //     _gaq.push(['_setAccount', value]);
                    //     _gaq.push(['_trackEvent', 'Media', 'show', atomid]);
                    // });


                });

            }

        },
        //Setzt einen Stadtspaziergang
        setGpx: function (url, instance) {


            if (instance.mapdata.walk) {
                instance.components.map.removeLayer(instance.mapdata.walk);
            }

            var gpx = new L.GPX(url + '?' + Date.now(), {
                async: true,
                marker_options: {
                    startIconUrl: '',
                    endIconUrl: '',
                    shadowUrl: instance.baseurl + 'img/pin-shadow.png'
                },
                polyline_options: {
                    color: '#00335a',
                    lineCap: 'round',
                    weight: 10
                }
            }).on('loaded', function (e) {
                instance.components.map.fitBounds(e.target.getBounds());
            });


            instance.mapdata.walk = gpx.addTo(instance.components.map);

        },
        //Initialisert den HTML5 Player und lädt in gegebenfalls in den DOM falls er dort noch nicht vorhanden ist
        setPlayer: function (atomid, instance) {
            //console.log("setPlayer");
            mGeoApp.tools.showLoader();

            var desc = "";
            var descitem = jQuery(".mgeoPlayer-description");
            descitem.hide();
            descitem.text("");
            if (mGeoApp.components.player.isLoaded || mGeoApp.components.player.isLoading) {

                jQuery.each(instance.data.waypoints(), function (key, value) {
                    if (value.UniqueIdentifier === atomid && value.WayPointDescription) {
                        descitem.text(value.WayPointDescription);
                        descitem.show();
                    }
                });
                mGeoApp.components.player.config.debug = true;
                mGeoApp.components.player.config.identifier = atomid;

                if (typeof mh5App !== "undefined" && mh5App && !jQuery.isEmptyObject(mh5App)) {

                    mh5App.resetPlayer(mGeoApp.components.player.config);
                }

            } else {
                mGeoApp.loadPlayer(atomid, instance);
            }
            //triggerd in mh5-components - jQuery("mh5playerwrapper").trigger(self.pinstance().playerid + "_Player:ready");
            jQuery("mh5playerwrapper").on(instance.playerid + "_Player:ready", function (event) {

                mGeoApp.components.player.wrapper.show();
                mGeoApp.tools.hideLoader();

            });


            mGeoApp.components.player.closeBtn.unbind().on("click", function () {
               // console.log("close btn click");
                mGeoApp.closePlayer("", instance);

            });


        },
        //Lädt den HTML5 Player in den DOM
        loadPlayer: function (atomid, instance) {


            mGeoApp.components.player.isLoading = true;
            //todo load where to?

            $('body').append('<div class="mgeoPlayerwrapper" id="' + instance.playerid + '" style= "display:none;"><div class="mgeoPlayer-close"></div><div class="mgeoPlayer-description" style="display:none;"></div><mh5playerwrapper></mh5playerwrapper></div>');

            mGeoApp.components.player.closeBtn = jQuery('.mgeoPlayer-close');
            mGeoApp.components.player.wrapper = jQuery('.mgeoPlayerwrapper');


            var initPlayerConf = {};
            initPlayerConf.identifier = atomid;
            initPlayerConf.config = 4;
            initPlayerConf.playerid = instance.playerid;
            initPlayerConf.sid = "nologin:";
            initPlayerConf.url = "https://h5.mediathek.at/config.php";

            initPlayerConf.seekTo = 0;
            initPlayerConf.seekEnd = 0;
            initPlayerConf.mediaLength = "0";
            initPlayerConf.overrideAutoplay = -1;
            initPlayerConf.morePageRefresh = 0;
            initPlayerConf.activeTab = "tab2";
            if (window.location !== window.parent.location) {
                initPlayerConf.config = 2;
            }

            mGeoApp.components.player.config = initPlayerConf;


            // Update the page content when the popstate event is called.
            window.addEventListener('popstate', function (event) {
                //updateContent(event.state)
                //closePlayer();
                mGeoApp.closePlayer("", instance);
            });


            var phpurl = "https://h5.mediathek.at/player.php?identifier=091071A8-169-00021-00000314-090FC364&jsn=1&raw=1";

            if (location && location !== undefined && location.hostname === "geo.web.mbit.at") {
                phpurl = "http://geo.web.mbit.at/player/player.php?identifier=091071A8-169-00021-00000314-090FC364&jsn=1";
            }


            $.when(
                $.ajax({
                    dataType: "json",
                    url: phpurl

                })
            ).done(function (scripts) {
                    var cssfiles = [];
                    var jsfiles = [];
                    var ignorescripts = ["knockout"];
                    jQuery.each(scripts, function (i, item) {
                        var ext = mGeoApp.tools.getFileExtension(item);
                        var curscript = item;
                        jQuery.each(ignorescripts, function (i, toIgnore) {
                            if (item.indexOf(toIgnore) > -1) {
                                curscript = "";
                            }
                        });
                        if (curscript) {
                            if (ext === "css") {
                                cssfiles.push(curscript);
                            } else if (ext === "js") {

                                jsfiles.push(curscript);
                            }
                        }

                    });
                    mGeoApp.tools.loadCss(cssfiles);
                    //mGeoApp.tools.loadCss([instance.baseurl + "css/mh5player.custom.css?" + Date.now()]);

                    mGeoApp.tools.loadScripts(jsfiles, function () {
                        mh5App.initPlayer(initPlayerConf);
                        mGeoApp.components.player.isLoaded = true;
                        mGeoApp.components.player.isLoading = false;
                        mGeoApp.root.trigger("mh5AppPlayer:loaded");
                        mGeoApp.tools.hideLoader();

                    });
                }
            );
        },
        //Lädt die Wegpunktdaten von der definierten URL
        loadWaypoints: function (instance) {
            $.ajax({
                url: mGeoApp.urls.waypoints.request
            }).done(function (result) {
                instance.setWaypoints(result.marker, instance);

            });

        },
        //Versucht die Geolocation des Nutzers zu finden
        getMyLocation: function (instance) {

            instance.components.map.locate({setView: false, maxZoom: 16, watch: true});

            function onLocationFound(e) {

                instance.data.mylocation(e);


            }

            function onLocationError(e) {
                //console.log(e.message);
            }

            instance.components.map.on('locationerror', onLocationError);


            instance.components.map.on('locationfound', onLocationFound);


        },
        //Lädt die einzelen Seitenmodule
        loadModules: function (instance) {
            //load templatefile
            $.when(
                // load your external HTML template
                $.ajax({
                    url: instance.baseurl + "/templates/all.html?" + Date.now()

                })
                    .done(function (templates) {
                        var source = $(templates);
                        $('#mh5maptemplates').remove();
                        $('body').append('<div style="display:none" id="mh5maptemplates">' + templates + '<\/div>');

                    })
            ).done(function () {
                //instance.root.empty();
                //instance.root.append('<mgeowrapper></mgeowrapper>');
                var elemInstance = document.getElementById('mgeowrapper');
                if (elemInstance && !ko.components.isRegistered('mgeowrapper')) {
                    ko.components.register('mgeowrapper', {
                        viewModel: function (params) {
                            var self = this;
                            self.instanceID = params.instanceID;
                            self.instance = ko.observable(mGeoApp.getMap(self.instanceID));

                            self.mapID = "map_" + self.instanceID;
                            //self.pinstance = instance;
                            // console.log("init instance:" + self.instance().instanceID + " id:" + self.instanceID);

                        },
                        template: {element: elemInstance}
                    });
                }

                var elemInstance = document.getElementById('mgeomap');
                if (elemInstance && !ko.components.isRegistered('mgeomap')) {
                    ko.components.register('mgeomap', {
                        viewModel: function (params) {
                            var self = this;
                            self.instance = params.instance;
                            //self.mapID = instance.instanceID;
                            //var map = jQuery("#map_" + instance.instanceID);

                            var mapid = "map_" + self.instance().instanceID;
                            self.instance().components.map = L.map(mapid, {
                                zoomControl: false,
                                closePopupOnClick: false
                            }).setView([48.2000, 16.3667], 13);
                            self.instance().components.map.addControl(L.control.zoom({position: "topright"}));
                            // L.tileLayer('http://otile1.mqcdn.com/tiles/1.0.0/osm/{z}/{x}/{y}.png?key=MEh0TPuFhEKqyrO90SvGSiC4gIeg2HIP', {
                            /*    L.tileLayer('http://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                             attribution: '&copy; <a href="http://osm.org/copyright">OpenStreetMap</a> contributors | Tiles Courtesy of <a href="http://www.mapquest.com/" target="_blank">MapQuest</a> <img src="http://developer.mapquest.com/content/osm/mq_logo.png">'
                             }).addTo(self.instance().components.map);
                             */
                            self.instance().components.map.attributionControl.addAttribution('<a href="https://www.netidee.at" class="netidee-attr"><img src="' + instance.baseurl + '../img/netidee-logo_s.png" width="150" /></a>');
                            MQ.mapLayer().addTo(self.instance().components.map);


                            if (self.instance().config.search.result) {
                                mGeoApp.setWaypoints(self.instance().config.search.result, self.instance());
                                /*
                                 if (self.instance().starterMarker) {
                                 mGeoApp.openMarkerPopup(self.instance().starterMarker, self.instance());
                                 }
                                 */
                            }
                        },
                        template: {element: elemInstance}
                    });
                }

                var showPanel = instance.config.config.config.showPanel === "1";
                var elemInstance = document.getElementById('mgeofilter');
                if (elemInstance && !ko.components.isRegistered('mgeofilter') && showPanel) {
                    ko.components.register('mgeofilter', {
                        viewModel: function (params) {
                            var self = this;
                            self.instance = params.instance;
                            mGeoApp.getMyLocation(self.instance());
                            self.searchword = ko.observable("");
                            if (self.instance().config.search.facet.Year) {
                                self.dateMin = self.instance().config.search.facet ? ko.observable(Number(self.instance().config.search.facet.Year[0].key)) : ko.observable(1900);
                                self.dateMax = self.instance().config.search.facet ? ko.observable(Number(jQuery(self.instance().config.search.facet.Year).last()[0].key)) : ko.observable(2015);
                            }
                            // if (self.instance().config.search.facet.DateUTC) {
                            //     self.dateMin = self.instance().config.search.facet ? ko.observable(Number(self.instance().config.search.facet.DateUTC[0].key)) : ko.observable(1900);
                            //     self.dateMax = self.instance().config.search.facet ? ko.observable(Number(jQuery(self.instance().config.search.facet.DateUTC).last()[0].key)) : ko.observable(2015);
                            // }
                            self.dateRangeMin = self.instance().config.config.dateRange.min;
                            self.dateRangeMax = self.instance().config.config.dateRange.max;


                            self.dateRange = ko.observable(self.dateMin() + "," + self.dateMax());
                            self.selectedTopics = ko.observableArray([]);
                            self.selectedPostalCode = ko.observable();
                            self.selectedPostalCodeGroup = ko.observable();
                            self.selectedClient = ko.observableArray([]);



                            self.components = self.instance().components;
                            self.data = self.instance().data;


                            self.Topics = self.instance().data.search.Topics;
                            self.Clients = self.instance().data.search.Clients;


                            self.filter = self.instance().components.filter;
                            self.filterresult = self.instance().components.filterresult;
                            self.walks = self.instance().components.walks;


                            self.navItems = ko.observableArray(self.instance().config.config.navi);

                            self.showOverlay = function (data) {
                                mGeoApp.showOverlay(data.uid, self.instance());

                            };

                            self.showShareUrl = function () {

                                mGeoApp.showOverlayWithContent(self.shareUrl(), 'shareUrl', self.instance());
                            };


                            function deselectAllTopics() {
                                var topics = [];

                                jQuery.each(self.Topics(), function (key, value) {
                                    self.Topics()[key].isChecked(false);
                                });

                            }

                            function deselectAllClients() {

                                jQuery.each(self.Clients(), function (key, value) {
                                    self.Clients()[key].isChecked(false);
                                });

                            }

                            function setTopics(swtGroup, selectedTopics) {


                                jQuery.each(self.Topics(), function (key, value) {
                                    var count = 0;
                                    var curid = value.id();
                                    var checked = false;
                                    if (swtGroup) {
                                        jQuery.each(swtGroup, function (i, facet) {
                                            if (String(curid) === String(facet.key)) {
                                                count = facet.value;
                                            }
                                        });
                                    }
                                    if (selectedTopics) {
                                        jQuery.each(selectedTopics, function (i, topicid) {
                                            if (String(curid) === String(topicid)) {
                                                checked = true;
                                            }
                                        });
                                    }
                                    self.Topics()[key].count(count);
                                    self.Topics()[key].isChecked(checked);
                                });


                            }

                            function setClients(selectedClients) {



                                jQuery.each(self.Clients(), function (key, value) {
                                    var count = 0;
                                    var curid = value.id();
                                    var checked = false;
                                    if (selectedClients > 0) {
                                        if (String(curid) === String(selectedClients)) {
                                              checked = true;
                                           }
                                    }
                                        // jQuery.each(selectedClients, function (i, clientid) {
                                        //     if (String(curid) === String(clientid)) {
                                        //         checked = true;
                                        //     }
                                        // });

                                    self.Clients()[key].isChecked(checked);
                                });


                            }


                            function setSelectedTopic(selectedTopics) {

                                if (selectedTopics) {
                                    jQuery.each(selectedTopics, function (i, id) {
                                        self.selectedTopics().push(String(id));
                                    });
                                }
                            }

                            self.showMyLocation = function () {

                                if (self.instance().data.mylocation()) {
                                    if (self.instance().mapdata.mypositioncircle) {
                                        self.instance().components.map.removeLayer(instance.mapdata.mypositioncircle);
                                    }

                                    var radius = self.instance().data.mylocation().accuracy / 2;
                                    var circle = L.circle(self.instance().data.mylocation().latlng, radius).addTo(self.instance().components.map);
                                    self.instance().mapdata.mypositioncircle = circle.addTo(self.instance().components.map);

                                    self.instance().components.map.fitBounds(circle.getBounds(), {maxZoom: 16});


                                }
                                self.instance().hideMeta(self.instance().instanceID);
                                self.navIsHidden(true);

                            };


                            self.showShareUrlOverlay = ko.observable(false);
                            self.shareUrl = ko.observable("");

                            self.toggleShareUrlOverlay = function () {
                                self.showShareUrlOverlay(!self.showShareUrlOverlay());
                            };


                            self.showResult = ko.observable(false);

                            self.dateTop = ko.computed(function () {
                                var date = self.dateRange().split(",");
                                return date[1];
                            });

                            self.dateBottom = ko.computed(function () {
                                var date = self.dateRange().split(",");
                                return date[0];
                            });


                            self.instance().components.filter.dateslider = jQuery("#ex2").slider({
                                min: Number(self.dateRangeMin),
                                max: Number(self.dateRangeMax),
                                value: [Number(self.dateMin()), Number(self.dateMax())],
                                step: 1,
                                tooltip: 'always'
                            });


                            self.resetClients = function () {
                                deselectAllClients();
                            };

                            self.resetTopics = function () {
                                deselectAllTopics();
                            };

                            self.showResetTopics = ko.computed(function () {
                                var show = false;
                                jQuery.each(self.Topics(), function (key, value) {
                                    if (value.isChecked()) {
                                        show = true;
                                    }

                                });
                                return show;

                            });
                            self.resetSearchWord = function () {
                                self.searchword("");
                            };

                            self.resetDateRange = function () {
                                self.dateRange(self.dateRangeMin + ',' + self.dateRangeMax);
                                self.instance().components.filter.dateslider.attr("value", self.dateRangeMin + ',' + self.dateRangeMax);
                                self.instance().components.filter.dateslider.slider('setValue', [Number(self.dateRangeMin), Number(self.dateRangeMax)]);
                            };


                            self.showResetDateRange = ko.computed(function () {
                                var date = self.dateRange().split(",");
                                var rtval = false;
                                if (Number(date[0]) !== Number(self.dateRangeMin) || Number(date[1]) !== Number(self.dateRangeMax)) {
                                    rtval = true;
                                }
                                return rtval;
                            });

                            self.resetPostalCode = function () {
                                self.selectedPostalCode("");
                            };

                            self.resetPostalCodeGroup = function () {
                                self.selectedPostalCodeGroup("");
                                self.resetPostalCode();
                            };


                            self.showResetPostalCode = ko.computed(function () {
                                var rtval = false;
                                if (self.selectedPostalCode()) {
                                    rtval = true;
                                }

                                return rtval;
                            });

                            self.showResetPostalCodeGroup = ko.computed(function () {
                                var rtval = false;
                                if (self.selectedPostalCodeGroup()) {
                                    rtval = true;
                                }

                                return rtval;
                            });


                            self.resetFilter = function () {
                                self.resetSearchWord();
                                self.resetDateRange();
                                self.resetTopics();
                                self.resetClients();
                                self.resetPostalCode();
                                self.resetPostalCodeGroup();
                                self.SendForm();
                                self.resetWalk();

                                if (self.instance().mapdata.walk) {
                                    self.instance().components.map.removeLayer(self.instance().mapdata.walk);
                                }
                                mGeoApp.showMeta(self.instance().instanceID);


                            };

                            self.resetWalk = function () {
                                self.walkDescription('');
                                self.walkDescriptionShort('');
                                self.walkTitle('');
                                //self.selectedWalk(ko.observable(''));
                                self.walks.selectedWalk('');
                                if (self.instance().mapdata.walk) {
                                    self.instance().components.map.removeLayer(self.instance().mapdata.walk);
                                }

                                History.pushState(null, $(document).find("title").text(), "?");
                                self.walks.isOpen = ko.observable(false);


                            };

                            self.showResetSection = ko.computed(function () {
                                var rtval = false;

                                if (self.showResetPostalCode() || self.showResetPostalCodeGroup() || self.showResetDateRange() || self.showResetTopics() || self.searchword() || self.Clients()) {
                                    rtval = true;
                                }

                                return rtval;
                            });


                            self.filter.isOpen = ko.observable(false);
                            self.walks.isOpen = ko.observable(false);
                            self.filterresult.isOpen = ko.observable(false);

                            self.instance().root.find('.collapseFilter-options').collapse({
                                toggle: false
                            });


                            self.toggleFilter = function () {
                                self.instance().root.find('.collapseFilter-options').collapse('toggle');
                                self.filter.isOpen(!self.filter.isOpen());

                                if (self.filter.isOpen()) {
                                    self.hideWalks();
                                    self.hideFilterresult();
                                }
                            };

                            self.hideFilter = function () {
                                self.instance().root.find('.collapseFilter-options').collapse('hide');
                                self.filter.isOpen(false);
                            };

                            self.toggleFilterResult = function () {
                                self.instance().root.find('.collapseFilter-result').collapse('toggle');
                                self.filterresult.isOpen(!self.filterresult.isOpen());

                                if (self.filterresult.isOpen()) {
                                    self.hideWalks();
                                    self.hideFilter();
                                }
                            };


                            self.hideFilterresult = function () {
                                self.instance().root.find('.collapseFilter-result').collapse('hide');
                                self.filterresult.isOpen(false);
                            };


                            self.toggleWalks = function () {
                                self.instance().root.find('.collapseFilter-walks').collapse('toggle');


                                self.walks.isOpen(!self.walks.isOpen());
                                if (self.walks.isOpen()) {
                                    self.hideFilter();
                                    self.hideFilterresult();
                                }

                            };

                            self.showWalks = function () {
                                self.instance().root.find('.collapseFilter-walks').collapse('toggle');


                                self.walks.isOpen(true);
                                if (self.walks.isOpen()) {
                                    self.hideFilter();
                                    self.hideFilterresult();
                                }

                            };


                            self.hideWalks = function () {
                                self.instance().root.find('.collapseFilter-walks').collapse('hide');
                                self.walks.isOpen(false);
                            };


                            self.PostalCodes = self.instance().data.search.PostalCodes;
                            self.PostalCodeGroups = self.instance().data.search.PostalCodeGroups;
                            self.Walks = self.instance().data.search.Walks;
                            self.walkDescription = ko.observable('');
                            self.walkDescriptionShort = ko.observable('');
                            self.walkTitle = ko.observable('');
                            // self.selectedWalk = ko.observable();
                            self.showPostalCodeSelect = ko.observable(false);

                            self.selectedPostalCodeGroup.subscribe(function (value) {
                                self.showPostalCodeSelect(false);
                                self.resetPostalCode();
                                if(value === '1XXX') {
                                    self.showPostalCodeSelect(true);
                                }
                            });


                            self.results = self.instance().data.waypoints;


                            function PostalCode(id, title, count) {
                                this.id = id;
                                this.title = title;
                                this.count = ko.observable(count);
                            }

                            var listofPostalCodes = [];
                            if (self.instance().config.search.facet && self.instance().config.search.facet.PlacePostalCode) {

                                jQuery.each(self.instance().config.search.facet.PlacePostalCode, function (i, facet) {
                                    jQuery.each(self.instance().config.config.PostalCodes, function (key, value) {
                                        if (parseInt(key) === parseInt(facet.key)) {
                                            listofPostalCodes.push(new PostalCode(key, value, facet.value));
                                        }
                                    });
                                });
                            } else {
                                jQuery.each(self.instance().config.config.PostalCodes, function (key, value) {
                                    listofPostalCodes.push(new PostalCode(key, value, 0));
                                });
                            }
                            self.PostalCodes(listofPostalCodes);


                            function PostalCodeGroups(id, title, postalCodes, count ) {
                                this.id = id;
                                this.title = title;
                                this.count = ko.observable(count);
                                this.postalCodes = postalCodes;
                            }


                            var listofPostalCodesGroups = [];
                            if (self.instance().config.search.facet && self.instance().config.search.facet.PlacePostalCodeGroups) {

                                jQuery.each(self.instance().config.search.facet.PlacePostalCodeGroups, function (i, facet) {
                                    jQuery.each(self.instance().config.config.PostalCodeGroups, function (key, value) {
                                        if (parseInt(key) === parseInt(facet.key)) {
                                            listofPostalCodesGroups.push(new PostalCodeGroups(key, value, facet.value));
                                        }
                                    });
                                });
                            } else {
                                jQuery.each(self.instance().config.config.PostalCodeGroups, function (key, value) {
                                    listofPostalCodesGroups.push(new PostalCodeGroups(key, value, 0));
                                });
                            }
                            self.PostalCodeGroups(listofPostalCodesGroups);


                            function Topic(id, title, count, isChecked) {
                                this.id = ko.observable(String(id));
                                this.title = title;
                                this.count = ko.observable(count);
                                this.isChecked = ko.observable(isChecked);
                            }

                            var listOfTopics = [];
                            jQuery.each(self.instance().config.config.swtGroups, function (key, value) {
                                var count = 0;
                                var checked = false;
                                if (self.instance().config.search.facet && self.instance().config.search.facet.SubjectTopicGroup) {
                                    jQuery.each(self.instance().config.search.facet.SubjectTopicGroup, function (i, facet) {

                                        if (parseInt(key) === parseInt(facet.key)) {
                                            count = facet.value;
                                        }

                                    });
                                }
                                listOfTopics.push(new Topic(key, value, count, checked));
                            });
                            self.Topics(listOfTopics);
                            //selectAllTopics();

                            function Client(id,name,count,isChecked) {
                                this.id = ko.observable(String(id));
                                this.name = name;
                                this.count = ko.observable(count);
                                this.isChecked = ko.observable(isChecked);
                            }

                            var listOfClients  = [];
                            jQuery.each(self.instance().config.config.clients, function (key, value) {
                                listOfClients.push(new Client(key,value,0,false));
                            });
                            self.Clients(listOfClients);

                            /*walks*/

                            function Walk(id, title, selected) {
                                this.id = id;
                                this.title = title;
                                this.selected = selected;
                            }


                            var request = {
                                arguments: {
                                    'run': 'list'
                                }
                            };
                            var setWalks = function (walks) {
                                var listOfWalks = [];
                                if (walks && walks.list) {
                                    jQuery.each(walks.list, function (key, value) {
                                        listOfWalks.push(new Walk(value.uid, value.title));
                                    });
                                }
                                self.Walks(listOfWalks);
                            }
                            mGeoApp.ajaxBridge.walk(request, setWalks);


                            self.navIsHidden = self.instance().components.filter.navIsHidden;


                            self.SearchisHidden = ko.observable(false);

                            self.toggleNav = function () {
                                self.navIsHidden(!self.navIsHidden());

                            };

                            self.curWalk = ko.observable();


                            function showWalk(id) {

                                if (String(self.curWalk()) === String(id)) {
                                    self.SendForm();
                                    self.curWalk("");

                                } else {

                                    var request = {
                                        arguments: {
                                            'run': 'detail',
                                            'walk': id
                                        }

                                    };
                                    // var setWalks = function(walks) {
                                    //     var listOfWalks = [];
                                    //     if (walks && walks.list) {
                                    //         jQuery.each(walks.list, function (key, value) {
                                    //             listOfWalks.push(new Walk(value.uid, value.title));
                                    //         });
                                    //     }
                                    //     self.Walks(listOfWalks);
                                    // }
                                    var setWalkData = function (walkdata) {
                                        self.walkDescription(walkdata.detail.longdesc);
                                        self.walkDescriptionShort(walkdata.detail.introduction);
                                        self.walkTitle(walkdata.detail.title);
                                        mGeoApp.setWaypoints(walkdata.detail.it, self.instance());
                                        mGeoApp.setGpx(walkdata.detail.wp, self.instance());
                                    }
                                    mGeoApp.ajaxBridge.walk(request, setWalkData);
                                    self.curWalk(id);
                                    //self.selectedWalk(ko.observable(id));
                                    // self.walks.selectedWalk(id);
                                }
                                History.pushState({
                                    state: "Walk",
                                    instanceID: instance.instanceID,
                                    walkid: id
                                }, $(document).find("title").text(), "?walk=" + id);


                                return true;


                            }


                            if (self.instance().components.walks.starterWalk) {
                                showWalk(self.instance().components.walks.starterWalk);
                                //self.selectedWalk(self.instance().components.walks.starterWalk);

                                self.walks.selectedWalk(self.instance().components.walks.starterWalk);
                                self.showWalks();
                            }


                            self.showWalk = function (data) {
                                return showWalk(data.id);
                            };


                            /*./ walks*/
                            self.instance().root.find('.input-searchword').keypress(function (e) {
                                if (e.which === 13) {
                                    self.instance().root.find('form').submit();
                                    return false;
                                }
                            });


                            /*Set Filter*/
                            var filter = self.instance().config.search.filter;

                            if (self.instance().config.search) {
                                self.searchword(self.instance().config.search.searchword);
                            }
                            if (filter) {

                                var dateBottom = filter.date && filter.date.min ? filter.date.min : self.dateMin();
                                var dateTop = filter.date && filter.date.max ? filter.date.max : self.dateMax();
                                jQuery("#ex2").slider('setValue', [Number(dateBottom), Number(dateTop)]);


                                if (filter.swtGroup) {
                                    setTopics(self.instance().config.search.facet.swtGroup, filter.swtGroup);
                                }

                                if (filter.postalCode) {
                                    self.selectedPostalCode(filter.postalCode);
                                }
                                if (filter.client) {
                                    setClients(filter.client);
                                }
                                if (filter.postalCodeGroup) {
                                    self.selectedPostalCodeGroup(filter.postalCodeGroup);
                                }
                                if (self.instance().config.searchurl) {
                                    self.shareUrl(self.instance().config.searchurl);
                                }

                            }
                            /* ./ Set Filter*/


                            self.SendForm = function (data) {

                                mGeoApp.tools.showLoader(self.instance());
                                self.resetWalk();
                                mGeoApp.hideMeta(self.instance().instanceID);


                                self.navIsHidden(true);


                                var request = self.instance().urls.search.request;
                                var date = (jQuery(self.instance().components.filter.dateslider).val()).split(",");
                                var selectedTopics = [];
                                var selectedClient = [];

                                jQuery.each(self.Topics(), function (key, value) {
                                    if (value.isChecked()) {
                                        selectedTopics.push(value.id);
                                    }
                                });
                                jQuery.each(self.Clients(), function (key, value) {
                                    if (value.isChecked()) {
                                        selectedClient.push(value.id());
                                    }
                                });

                                var filter = {
                                    swtGroup: selectedTopics,
                                    date:
                                        {
                                            min: date[0],
                                            max: date[1]
                                        },
                                    postalCode: self.selectedPostalCode(),
                                    postalCodeGroup: self.selectedPostalCodeGroup(),
                                    client: selectedClient

                                };
                                urlParser.writeUrl(filter,self.searchword());

                                filter.date.fmin = this.dateRangeMin;
                                filter.date.fmax = this.dateRangeMax;

                                var p = {
                                    searchword: self.searchword(),
                                    filter: filter
                                };


                                var request = {
                                    run: 'search',
                                    arguments: {
                                        'params': p
                                    }
                                };

                                var setSearchResult = function (response) {
                                    //do something

                                    if (response && response.result) {
                                        mGeoApp.setWaypoints(response.result, self.instance());
                                        setTopics(response.facet.SubjectTopicGroup, response.filter.swtGroup);
                                        self.shareUrl(response.searchurl);

                                        if (response.filter.date && response.filter.date.min && response.filter.date.max) {
                                            var first = response.filter.date.min;
                                            var last = response.filter.date.max;
                                            jQuery("#ex2").slider('setValue', [Number(first), Number(last)]);
                                        }
                                    } else if (response && !response.result) {
                                        mGeoApp.setWaypoints([], self.instance());
                                        self.shareUrl(response.searchurl);
                                    }

                                    //todo fehlerbehandlung
                                    mGeoApp.tools.hideLoader();
                                };
                                mGeoApp.ajaxBridge.search(request, setSearchResult);

                            };


                            self.focusMarker = function (data) {
                                self.navIsHidden(true);
                                mGeoApp.openMarkerPopup(data.UniqueIdentifier, self.instance());


                            };

                            mGeoApp.tools.initScroller('.mgeo-scrollable');
                        },
                        template: {element: elemInstance}

                    });
                }

                var mapmodel = {};
                var mapdom = document.getElementById(instance.instanceID);
                //ko.applyBindings(mapmodel, document.getElementsByTagName("mgeowrapper")[0]);
                ko.applyBindings(mapmodel, mapdom);


            });
        },
        clearLayers: function (instance) {
            if (instance && instance.mapdata && instance.mapdata.layerGroups && instance.mapdata.layerGroups().length > 0) {
                $.each(instance.mapdata.layerGroups(), function (key, value) {
                    value.clearLayers(instance);
                });
            }
        },
        tools: {
            //Initialisiert den JqueryScroller
            initScroller: function (selector) {
                jQuery(selector).jScrollPane({
                    autoReinitialise: true,
                    verticalDragMinHeight: 45

                });


            },
            //Lädt Scripte
            loadScripts: function (scriptPaths, callback) {
                var progress = 0;
                var internalCallback = function () {
                    if (++progress === scriptPaths.length) {
                        callback();
                    }
                };
                scriptPaths.forEach(function (script) {

                    if (location && location !== undefined && location.hostname === "mt.web.mbit.at" && script === "http:\/\/h5-dev.mediathek.at\/js\/playermanager.js") {
                        script = "http:\/\/player.web.mbit.at\/js\/playermanager.js";
                        console.log("loaded local playermanger.js")
                    }

                    $.getScript(script, internalCallback);
                });
            },
            //Fügt CSS in das DOM Element Head ein
            loadCss: function (cssPaths) {

                cssPaths.forEach(function (item) {
                    $("<link/>", {
                        rel: "stylesheet",
                        type: "text/css",
                        href: item
                    }).appendTo("head");
                });
            },
            setDivPosition: function (yTarget, yEvent, yParent, yCloseButton) {
                var info = $(yTarget);
                if (yCloseButton) {
                    info.find(yCloseButton)
                        .off("click")
                        .on("click", function (event) {
                            info.hide();
                        });
                }
                var src = $(yEvent.target);
                var cWidth = $(yParent).width();
                //var cHeight = $(yParent).height();
                var cHeight = $(yParent)[0].scrollHeight;
                var targetX = src.position().left - info.width();
                var targetY = src.position().top;
                //var targetY = 0;
                if (targetX + info.width() > cWidth) {
                    targetX += cWidth - (targetX + info.width());
                } else if (targetX < 0) {
                    targetX = 0;
                }


                if (info.height() >= cHeight) {
                    targetY = 0;
                } else if (targetY + info.height() > cHeight) {
                    targetY += cHeight - (targetY + info.height());
                } else if (targetY < 0) {
                    targetY = 0;
                }

                if (cHeight < info.height()) {
                    targetY += ($(yParent).height() - info.height());
                }

                info.css('left', targetX + 'px')
                    .css('top', targetY + 'px');
                // info.show();

                return 0;
            },
            //Liest den Dateityp einer Datei anhand der Dateiendung aus
            getFileExtension: function (url) {


                url = url.substring(0, (url.indexOf("#") === -1) ? url.length : url.indexOf("#"));
                url = url.substring(0, (url.indexOf("?") === -1) ? url.length : url.indexOf("?"));
                url = url.substring(url.lastIndexOf("/") + 1, url.length);
                url = (/[.]/.exec(url)) ? /[^.]+$/.exec(url) : undefined;
                if (url) {
                    return url[0];
                }

                return url;
            },
            //Erkennt op es sich um ein Mobilgerät handelt
            isMobile: function () {
                var check = false;
                (function (a) {
                    if (/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino/i.test(a) || /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(a.substr(0, 4)))
                        check = true;
                })(navigator.userAgent || navigator.vendor || window.opera);
                mGeoApp.isMobile = check;
            },
            //Zeigt den Ladeicon an
            showLoader: function (instance) {
                jQuery('.mgeo-loader-wrapper').show();
            },
            //Blendet den Ladeicon aus
            hideLoader: function (instance) {
                jQuery('.mgeo-loader-wrapper').hide();
            }
        },
        showOverlayFromUrl: function (url, id, instance) {
            if (!instance) {
                instance = mGeoApp.maps()[0];
            }
            var target = jQuery(".mgeo-overlay-scrollerwrap");

            if (!target.length) {
                jQuery('body').append('<div style="display:none" class="mgeo-overlay-wrapper mgeo-overlay-scrollerwrap"> <div class="mgeo-overlay"><div class="mgeo-overlay-close"></div><div class="mgeo-scrollable"><div class="mgeo-overlay-content"><div></div></div></div><\/div></div>');
                target = jQuery(".mgeo-overlay-scrollerwrap");
            }
            target.attr("id", "overlay_" + id);


            target.find(".mgeo-overlay-close")
                .off("click")
                .on("click", function (event) {
                    target.hide();
                });

            var tcontent = target.find(".mgeo-overlay-content");

            tcontent.load(url + " .inhalt_lightbox", function (response, status, xhr) {
                target.show();
                mGeoApp.tools.initScroller('.mgeo-scrollable', instance);

            });

        },
        //Öffnet ein Overlay und befüllt es mit dem übergebenen Inhalt
        showOverlayWithContent: function (content, id, instance) {
            if (!instance) {
                instance = mGeoApp.maps()[0];
            }
            var target = jQuery(".mgeo-overlay-wrapper");

            if (!target.length) {
                jQuery('body').append('<div style="display:none" class="mgeo-overlay-wrapper"> <div class="mgeo-overlay"><div class="mgeo-overlay-close"></div><div class="mgeo-scrollable"><div class="mgeo-overlay-content"><div></div></div></div><\/div></div>');
                target = jQuery(".mgeo-overlay-wrapper");
            }
            target.attr("id", id);


            target.find(".mgeo-overlay-close")
                .off("click")
                .on("click", function (event) {
                    target.hide();
                });

            var tcontent = target.find(".mgeo-overlay-content");
            tcontent.html(content);
            target.show();

        },
        //Versteckt die MetaNavigation
        hideMeta: function (instanceID) {
            jQuery('#header').addClass("hidden-xs");
            jQuery('#footer').addClass("hidden-xs");
            jQuery('#' + instanceID + '.content_container').addClass("mgeo-fullheight");

        },
        //Zeit die MetaNavigation an
        showMeta: function (instanceID) {
            jQuery('#header').removeClass("hidden-xs");
            jQuery('#footer').removeClass("hidden-xs");
            jQuery('#' + instanceID + '.content_container').removeClass("mgeo-fullheight");
        },
        //Öffnet ein Overlay
        showOverlay: function (id, name, instance) {
            if (!instance) {
                instance = mGeoApp.maps()[0];
            }
            var pages = instance.config.config.navi;
            var curpage = "";
            var curid = "";
            if (pages) {

                jQuery.each(pages, function (key, value) {

                    if (value && value.uid === id) {
                        curpage = value;
                    }
                });

                var url = instance.config.config.config.contentUrl + curpage.uid;

                mGeoApp.showOverlayFromUrl(url, id);

            }
        },
        ajaxBridge: {
            ajaxUrl: '',
            init: function (data, callBack) { //tx_ajaxbridge_bridge[request][run]=mh5compMorecontent
                var request = {
                    run: 'init',
                    arguments: data.arguments
                };
                this.call(request, callBack);

            },
            walk: function (data, callBack) { //tx_ajaxbridge_bridge[request][run]=mh5compMorecontent
                var request = {
                    run: 'walk',
                    arguments: data.arguments
                };
                this.call(request, callBack);

            },
            search: function (data, callBack) { //tx_ajaxbridge_bridge[request][run]=mh5compMorecontent
                var request = {
                    run: 'search',
                    arguments: data.arguments
                };
                this.call(request, callBack);

            },
            call: function (request, callback) {
                var defaultParams = {
                    request: request
                };
                try {
                    $.post(ajaxUrl, defaultParams, function (data) {
                        mGeoApp.ajaxBridge.callResult(data, callback)
                    }, "json");
                } catch (e) {
                    console.log(e);
                }
            },
            callResult: function (json, callback) {
                try {
                    if (json && json.Success) {
                        callback(json.Data);
                    }

                } catch (e) {
                    console.log(e);
                }
            },
        },
    };
})(jQuery);


